Flatpaking
==========

`Flatpak <https://flatpak.org/>`_ is perfect for packaging applications for Linux.

Flatpak comes with
`great documentation <https://docs.flatpak.org/en/latest/index.html>`_ and a
specific guide about using it to package Python applications can be found
`here <https://docs.flatpak.org/en/latest/python.html>`_.
