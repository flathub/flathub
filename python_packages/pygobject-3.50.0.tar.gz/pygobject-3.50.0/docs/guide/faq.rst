==========================
Frequently Asked Questions
==========================

How can I use PyGObject with the official CPython builds on Windows?
--------------------------------------------------------------------

https://sourceforge.net/projects/pygobjectwin32 provides binaries which should
be ABI compatible with the official CPython binaries. I'd recommend using
msys2 if at all possible, since there are more people involved and it's easier
to fix/patch things yourself.
