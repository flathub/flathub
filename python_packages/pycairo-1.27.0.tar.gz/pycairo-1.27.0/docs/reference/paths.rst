.. _paths:

*****
Paths
*****

.. currentmodule:: cairo

class Path()
============

.. autoclass:: cairo.Path
