=======
Contact
=======

Issue Tracker
    If you have any questions, problems or want to give feedback please file
    an issue in our `issue tracker
    <https://gitlab.gnome.org/GNOME/pygobject/issues>`__.

IRC
    For chatting with the community we have an IRC channel named
    ``#python`` on ``irc.gnome.org``. Logs for the channel are available at
    https://quodlibet.duckdns.org/irc/pygobject.

Mailing List
    If you want to start a discussion with the Python community that is part
    of the GNOME project use the mailing list at
    https://mail.gnome.org/mailman/listinfo/python-hackers-list.

StackOverflow / StackExchange
    If you have technical questions about PyGObject you can find answers on
    `Stack Overflow <https://stackoverflow.com/questions/tagged/pygobject>`__.
    When asking there please use the tag `PyGObject`.

If you are unsure which communication channel to use **please use the issue
tracker**.
