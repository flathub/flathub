=================
Further Resources
=================

`Python GTK 3 Tutorial <https://python-gtk-3-tutorial.readthedocs.io>`__
    Many examples showing how to build an application using PyGObject and GTK.

`Python GI API Reference <https://lazka.github.io/pgi-docs>`__
    Auto generated API documentation for many libraries accessible through
    PyGObject.
