moviepy.video.fx.all.blink
==========================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: blink