moviepy.video.fx.all.margin
===========================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: margin