moviepy\.video\.fx\.all\.mask\_and
==================================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: mask_and