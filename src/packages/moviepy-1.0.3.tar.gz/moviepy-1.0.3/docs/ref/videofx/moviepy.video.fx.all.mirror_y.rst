moviepy.video.fx.all.mirror_y
=============================

.. currentmodule:: moviepy.video.fx.all

.. autofunction:: mirror_y