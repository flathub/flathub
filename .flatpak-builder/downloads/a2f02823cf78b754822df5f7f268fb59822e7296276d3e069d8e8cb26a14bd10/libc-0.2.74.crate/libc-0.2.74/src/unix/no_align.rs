s! {
    pub struct in6_addr {
        pub s6_addr: [u8; 16],
        __align: [u32; 0],
    }
}
