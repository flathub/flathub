use proc_macro_error::proc_macro_error;

#[proc_macro_error]
fn main() {}
