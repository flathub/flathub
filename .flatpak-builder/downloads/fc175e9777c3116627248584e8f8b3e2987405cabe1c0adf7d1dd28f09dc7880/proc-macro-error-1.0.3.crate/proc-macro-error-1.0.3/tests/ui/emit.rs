extern crate test_crate;
use test_crate::*;

emit!(one, two, three, four, five);
emit_notes!(one, two);

fn main() {}
