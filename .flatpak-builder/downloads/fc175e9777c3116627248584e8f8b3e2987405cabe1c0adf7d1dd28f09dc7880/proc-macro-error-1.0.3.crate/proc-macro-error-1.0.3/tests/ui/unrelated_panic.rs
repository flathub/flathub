extern crate test_crate;
use test_crate::*;

unrelated_panic!();

fn main() {}
