extern crate test_crate;
use test_crate::*;

option_ext!(one, two);

fn main() {}
