extern crate test_crate;
use test_crate::*;

to_tokens_span!(std::option::Option);

fn main() {}
