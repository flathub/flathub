extern crate test_crate;
use test_crate::*;

children_messages!(one, two, three, four);

fn main() {}
