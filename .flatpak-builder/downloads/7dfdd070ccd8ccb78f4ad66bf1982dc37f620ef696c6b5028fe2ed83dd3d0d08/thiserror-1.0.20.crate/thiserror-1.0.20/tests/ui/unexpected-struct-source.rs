use thiserror::Error;

#[derive(Error, Debug)]
#[source]
pub struct Error;

fn main() {}
