# pango [![Build Status](https://travis-ci.org/gtk-rs/pango.png?branch=master)](https://travis-ci.org/gtk-rs/pango) [![Build status](https://ci.appveyor.com/api/projects/status/9nyo0226rxvikdtm?svg=true)](https://ci.appveyor.com/project/GuillaumeGomez/pango) [![Gitter](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/gtk-rs/gtk)

Pango bindings for Rust.

- [Gtk-rs project site](http://gtk-rs.org/)

- [Online documentation](http://gtk-rs.org/docs/)

- [Readme](https://github.com/gtk-rs/gtk/blob/master/README.md) in our
  [main repo](https://github.com/gtk-rs/gtk)

## License

MIT
