# gdk-pixbuf [![Build Status](https://travis-ci.org/gtk-rs/gdk-pixbuf.png?branch=master)](https://travis-ci.org/gtk-rs/gdk-pixbuf) [![Build status](https://ci.appveyor.com/api/projects/status/5gcteolq1p274tue?svg=true)](https://ci.appveyor.com/project/GuillaumeGomez/gdk-pixbuf) [![Gitter](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/gtk-rs/gtk)

Gdk-Pixbuf bindings for Rust.

- [Gtk-rs project site](http://gtk-rs.org/)

- [Online documentation](http://gtk-rs.org/docs/)

- [Readme](https://github.com/gtk-rs/gtk/blob/master/README.md) in our
  [main repo](https://github.com/gtk-rs/gtk)

## License

MIT
