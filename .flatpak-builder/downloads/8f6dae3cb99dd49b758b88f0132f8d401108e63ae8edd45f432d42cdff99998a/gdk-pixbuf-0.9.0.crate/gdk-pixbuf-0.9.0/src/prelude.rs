//! Traits inteded for blanket imports.

pub use auto::traits::*;
#[doc(hidden)]
pub use glib::prelude::*;
pub use PixbufAnimationExt;
