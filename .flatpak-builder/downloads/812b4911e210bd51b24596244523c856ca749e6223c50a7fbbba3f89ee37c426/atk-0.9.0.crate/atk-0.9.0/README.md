# atk [![Build Status](https://travis-ci.org/gtk-rs/atk.png?branch=master)](https://travis-ci.org/gtk-rs/atk) [![Build status](https://ci.appveyor.com/api/projects/status/gaybdnw603c942a0?svg=true)](https://ci.appveyor.com/project/GuillaumeGomez/atk) [![Gitter](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/gtk-rs/atk)

[Project site](http://gtk-rs.org/) | [Online documentation](http://gtk-rs.org/docs/)

__Rust__ bindings and wrappers for __Atk__.

## License

__Atk__ is available under the MIT License, please refer to it.
