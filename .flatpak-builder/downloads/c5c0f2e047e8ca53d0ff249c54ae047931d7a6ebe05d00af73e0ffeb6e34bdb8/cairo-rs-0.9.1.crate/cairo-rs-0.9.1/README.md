# cairo [![Build Status](https://travis-ci.org/gtk-rs/cairo.png?branch=master)](https://travis-ci.org/gtk-rs/cairo) [![Build status](https://ci.appveyor.com/api/projects/status/9q998histb9vk2o2?svg=true)](https://ci.appveyor.com/project/GuillaumeGomez/cairo-p0df1) [![Gitter](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/gtk-rs/gtk)

Cairo bindings for Rust.

- [Gtk-rs project site](http://gtk-rs.org/)

- [Online documentation](http://gtk-rs.org/docs/)

- [Readme](https://github.com/gtk-rs/gtk/blob/master/README.md) in our
  [main repo](https://github.com/gtk-rs/gtk)

![screenshot](http://guillaume-gomez.fr/image/cairo.png)

## License

MIT
