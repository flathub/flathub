"""WSelector - A desktop application for browsing and downloading wallpapers from Wallhaven."""

from wselector.app import WSelectorApp

__version__ = "0.1.3"
__all__ = ['WSelectorApp']
